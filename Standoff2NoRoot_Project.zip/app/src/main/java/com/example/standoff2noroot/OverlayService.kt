package com.example.standoff2noroot

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(0xEE171C27.toInt())
        }
        val heading = TextView(this).apply {
            text = "NOROOT • PANEL"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val status = TextView(this).apply {
            text = "Демонстрационный режим включён"
            textSize = 13f
            setTextColor(0xFFB9C4D8.toInt())
            setPadding(0, 10, 0, 10)
        }
        val close = Button(this).apply {
            text = "Закрыть"
            setOnClickListener { stopSelf() }
        }
        view.addView(heading)
        view.addView(status)
        view.addView(close)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 120
        }
        windowManager?.addView(view, params)
        panel = view
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        panel?.let { windowManager?.removeView(it) }
        panel = null
        windowManager = null
        super.onDestroy()
    }
}
