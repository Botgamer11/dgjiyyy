package com.example.standoff2noroot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(0xFF10131A.toInt())
        }
        val title = TextView(this).apply {
            text = "NoRoot Panel"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val info = TextView(this).apply {
            text = "Безопасная демонстрационная панель поверх приложений. Не изменяет игры и не автоматизирует игровой процесс."
            textSize = 15f
            setTextColor(0xFFCDD3DF.toInt())
            setPadding(0, 20, 0, 24)
        }
        val permission = Button(this).apply {
            text = "Разрешить отображение поверх окон"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        }
        val start = Button(this).apply {
            text = "Показать панель"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(permission)
        layout.addView(start)
        setContentView(layout)
    }
}
