package com.naswayq.standoffoverlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            setBackgroundColor(Color.rgb(24, 29, 40))
        }
        content.addView(TextView(this).apply {
            text = "SO2  /  QUICK PANEL"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 14)
        })
        content.addView(TextView(this).apply {
            text = "Профиль: стандартный"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        })
        content.addView(Button(this).apply {
            text = "Сменить профиль"
            setOnClickListener {
                val label = content.getChildAt(1) as TextView
                label.text = if (label.text.toString().endsWith("стандартный"))
                    "Профиль: точный" else "Профиль: стандартный"
            }
        })
        content.addView(TextView(this).apply {
            text = "Тренировка: таймер"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 12, 0, 0)
        })
        content.addView(Button(this).apply {
            text = "Закрыть панель"
            setOnClickListener { stopSelf() }
        })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 120
        }

        panel = content
        windowManager.addView(content, params)
    }

    override fun onDestroy() {
        panel?.let { view ->
            if (view.isAttachedToWindow) windowManager.removeView(view)
        }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
