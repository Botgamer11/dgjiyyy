package com.naswayq.standoffoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "SO2 Overlay\nПлавающая панель настроек"
            textSize = 22f
        })
        layout.addView(TextView(this).apply {
            text = "Панель показывает только собственные настройки интерфейса. Она не читает память игры и не меняет игровой процесс."
            textSize = 14f
            setPadding(0, 20, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "Разрешить отображение поверх окон"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    startOverlay()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Запустить панель"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startOverlay()
                else {
                    startActivity(Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    ))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Остановить панель"
            setOnClickListener {
                stopService(Intent(this, OverlayService::class.java))
            }
        })
        setContentView(layout)
    }

    private fun startOverlay() {
        startService(Intent(this, OverlayService::class.java))
    }
}
